import * as actions from "redux/constant/types";

const intialState = {
 userItemsLoad: false,
  userItems: undefined,
};

// User reducer start
export const userItemReducer = (state = intialState, action) => {
  switch (action.type) {
    case actions.USER_ITEMS_LOAD:
      return {
        ...state,
        userItemsLoad: true,
      };

    case actions.USER_ITEMS_SUCCESS:
      return {
        ...state,
        userItemsLoad: false,
        userItems: action.payload,
      };
    
    default:
      return state;
  }
};
