import { combineReducers } from "redux";
import { contactReducer } from "./contactReducer";
import { menuItemReducer, footerItemsReducer } from "./headerFooterReducer";
import { homeItemReducer } from "./homePageReducer";
import { userProfileReducer } from "./userProfileReducer";
import { productReducer } from "./productReducer";
import { userItemReducer } from "./userPageReducer";
 import { userDetailsReducer } from "./userDetailReducer";
import { discoverItemReducer } from "./discoverPageReducer";
import { taskReducer } from "./taskReducer";

import toastReducer from "./toastReducer";

export default combineReducers({
  toast: toastReducer,
  contact: contactReducer,
  menuItem: menuItemReducer,
  footerItems: footerItemsReducer,
  homePageItems: homeItemReducer,
  userProfile: userProfileReducer,
  user: userItemReducer,
  taskPageItems: taskReducer,
  userDetails: userDetailsReducer,
  product: productReducer,
  discover: discoverItemReducer,
});
