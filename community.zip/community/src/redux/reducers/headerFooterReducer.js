import * as actions from "redux/constant/types";

const intialState = {
  menuItems: [],
  footerItems: null
};

// Header reducer start
export const menuItemReducer = (state = intialState, action) => {
  switch (action.type) {
    case actions.MENU_ITEMS_SUCCESS:
      return {
        ...state,
        menuItems: action.payload,
      };
    default:
      return state;
  }
};

// Footer reducer start
export const footerItemsReducer = (state = intialState, action) => {
  switch (action.type) {
    case actions.FOOTER_ITEMS_SUCCESS:
      return {
        ...state,
        footerItems: action.payload,
      };
    default:
      return state;
  }
};
