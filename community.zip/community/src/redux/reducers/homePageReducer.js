import * as actions from "redux/constant/types";

const intialState = {
  homeItemsLoad: false,
  homeItems: undefined,
  trendingAndfeatureLoad: false,
  trendingAndfeatureItems: undefined,
  allpostItemsLoad: false,
  allpostItems: undefined,
};

// Home reducer start
export const homeItemReducer = (state = intialState, action) => {
  switch (action.type) {
    case actions.HOME_ITEMS_LOAD:
      return {
        ...state,
        homeItemsLoad: true,
      };

    case actions.HOME_ITEMS_SUCCESS:
      return {
        ...state,
        homeItemsLoad: false,
        homeItems: action.payload,
      };
    case actions.TRENDING_ITEMS_LOAD:
      return {
        ...state,
        trendingAndfeatureLoad: true,
      };
    case actions.TRENDING_ITEMS_SUCCESS:
      return {
        ...state,
        trendingAndfeatureLoad: false,
        trendingAndfeatureItems: action.payload,
      };

      case actions.ALLPOST_ITEMS_LOAD:
      return {
        ...state,
        allpostItemsLoad: true,
      };
    case actions.ALLPOST_ITEMS_SUCCESS:
      return {
        ...state,
        allpostItemsLoad: false,
        allpostItems: action.payload,
      };
    default:
      return state;
  }
};
