import * as actions from "redux/constant/types";

const intialState = {
 userDetailsLoad: false,
  userDetails: undefined,
};

// User reducer start
export const userDetailsReducer = (state = intialState, action) => {
  //console.log("action", action )
  switch (action.type) {
    case actions.USER_DETAILS_LOAD:
      return {
        ...state,
        userDetailsLoad: true,
      };

    case actions.USER_DETAILS_SUCCESS:
      return {
        ...state,
        userDetailsLoad: false,
        userDetails: action.payload,
      };
    
    default:
      return state;
  }
};
