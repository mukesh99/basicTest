const intialState = {
  isToastOpen: false,
  toastMessage: undefined,
  toastVariant: undefined
};

export const toastReducer = (state = intialState, action) => {
  switch (action.type) {
    case "TOAST_OPEN":
      return {
        ...state,...action.payload
      };
    default:
      return state;
  }
};

export default toastReducer;
