export const CREATE_CONTACT = "CREATE_CONTACT";
export const GET_CONTACT = "GET_CONTACT";
export const UPDATE_CONTACT = "UPDATE_CONTACT";
export const DELETE_CONTACT = "DELETE_CONTACT";
export const SELECT_CONTACT = "SELECT_CONTACT";
export const CLEAR_CONTACT = "CLEAR_CONTACT";
export const DELETE_SELECTED_CONTACT = "DELETE_SELECTED_CONTACT";

// Global element types
export const TOAST_OPEN = "TOAST_OPEN";

// Header menu items types
export const MENU_ITEMS_LOAD = "MENU_ITEMS_LOAD";
export const MENU_ITEMS_SUCCESS = "MENU_ITEMS_SUCESS";

// Footer items types
export const FOOTER_ITEMS_LOAD = "FOOTER_ITEMS_LOAD";
export const FOOTER_ITEMS_SUCCESS = "FOOTER_ITEMS_SUCESS";

// Home page items types
export const HOME_ITEMS_LOAD = "HOME_ITEMS_LOAD";
export const HOME_ITEMS_SUCCESS = "HOME_ITEMS_SUCCESS";

// User infromation items types
export const USER_PROFILE_LOAD = "USER_PROFILE_LOAD";
export const USER_PROFILE_SUCCESS = "USER_PROFILE_SUCCESS";

// Top ranking users types
export const RANKING_USERS_LOAD = "RANKING_USERS_LOAD";
export const RANKING_USERS_SUCCESS = "RANKING_USERS_SUCCESS";

// Prodcut page types
export const PRODUCT_SERIES_LOAD = "PRODUCT_SERIES_LOAD";
export const PRODUCT_SERIES_SUCCESS = "PRODUCT_SERIES_SUCCESS";

// Discover page types
export const DISCOVER_ITEMS_LOAD = "DISCOVER_ITEMS_LOAD";
export const DISCOVER_ITEMS_SUCCESS = "DISCOVER_ITEMS_SUCCESS";

// trending section types
export const TRENDING_ITEMS_LOAD = "TRENDING_ITEMS_LOAD";
export const TRENDING_ITEMS_SUCCESS = "TRENDING_ITEMS_SUCCESS";

// User section types
export const USER_ITEMS_LOAD = "USER_ITEMS_LOAD";
export const USER_ITEMS_SUCCESS = "USER_ITEMS_SUCCESS";

// User profile details section
export const USER_DETAILS_LOAD = "USER_DETAILS_LOAD";
export const USER_DETAILS_SUCCESS = "USER_DETAILS_SUCCESS";

// All post Items 
export const ALLPOST_ITEMS_LOAD = "ALLPOST_ITEMS_LOAD";
export const ALLPOST_ITEMS_SUCCESS = "ALLPOST_ITEMS_SUCCESS";

// Task section types
export const ALLTASK_ITEMS_LOAD = "ALLTASK_ITEMS_LOAD";
export const ALLTASK_ITEMS_SUCCESS = "ALLTASK_ITEMS_SUCCESS";

