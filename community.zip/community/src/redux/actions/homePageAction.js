import axios from "axios";
import * as actions from "redux/constant/types";
import { baseUrl } from "core/utils";
import { toastOpen } from "redux/actions/toastAction";

//  Home page action start
export const homeItemsLoad = () => ({
  type: actions.HOME_ITEMS_LOAD,
});

export const homeItemsSucces = (res) => ({
  type: actions.HOME_ITEMS_SUCCESS,
  payload: res,
});

export const getHomeItems = () => {
  return async (dispatch) => {
    dispatch(homeItemsLoad());
    await axios
      .get(`${baseUrl}/home`)
      .then((res) => {
        if (res) {
          dispatch(homeItemsSucces(res.data));
        }
      })
      .catch((err) => {
        dispatch(toastOpen({
          isToastOpen: true,
          toastMessage: err.message,
          toastVariant: "error",
        }));
      });
  };
};

//  treniding page action start
export const trendingItemsLoad = () => ({
  type: actions.TRENDING_ITEMS_LOAD,
});

export const trendingItemsSucces = (res) => ({
  type: actions.TRENDING_ITEMS_SUCCESS,
  payload: res,
});

export const getTrendingItems = () => {
  return async (dispatch) => {
    dispatch(trendingItemsLoad());
    await axios
      .get(`${baseUrl}/trending`)
      .then((res) => {
        if (res) {
          dispatch(trendingItemsSucces(res.data));
        }
      })
      .catch((err) => {
        dispatch(toastOpen({
          isToastOpen: true,
          toastMessage: err.message,
          toastVariant: "error",
        }));
      });
  };
};

//All post action start here 

export const allpostItemsLoad = () => ({
  type: actions.ALLPOST_ITEMS_LOAD,
});

export const allpostItemsSucces = (res) => ({
  type: actions.ALLPOST_ITEMS_SUCCESS,
  payload: res,
});

export const getAllpostItems = () => {
  return async (dispatch) => {
    dispatch(allpostItemsLoad());
    await axios
      .get(`${baseUrl}/allPost`)
      .then((res) => {
        if (res) {
          dispatch(allpostItemsSucces(res.data));
        }
      })
      .catch((err) => {
        dispatch(toastOpen({
          isToastOpen: true,
          toastMessage: err.message,
          toastVariant: "error",
        }));
      });
  };
};