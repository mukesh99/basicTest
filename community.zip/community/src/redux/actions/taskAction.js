import axios from "axios";
import * as actions from "redux/constant/types";
import { baseUrl } from "core/utils";
import { toastOpen } from "redux/actions/toastAction";

//  User page action start
export const alltaskLoad = () => ({
  type: actions.ALLTASK_ITEMS_LOAD,
});

export const alltaskSucces = (res) => ({
  type: actions.ALLTASK_ITEMS_SUCCESS,
  payload: res,
});

export const getallTaskItems = () => {
  return async (dispatch) => {
    dispatch(alltaskLoad());
    await axios
      .get(`${baseUrl}/task`)
      .then((res) => {
        //console.log("items coming", res)
        if (res) {
          dispatch(alltaskSucces(res.data));
        }
      })
      .catch((err) => {
        dispatch(toastOpen({
          isToastOpen: true,
          toastMessage: err.message,
          toastVariant: "error",
        }));
      });
  };
};