import axios from "axios";
import * as actions from "redux/constant/types";
import { baseUrl } from "core/utils";
import { toastOpen } from "./toastAction";

//  Discover page action start
export const discoverLoad = () => ({
  type: actions.DISCOVER_ITEMS_LOAD,
});

export const discoverSuccess = (res) => ({
  type: actions.DISCOVER_ITEMS_SUCCESS,
  payload: res,
});

export const getDiscover = (productId) => {
  return async (dispatch) => {
    dispatch(discoverLoad());
    await axios
      .get(`${baseUrl}/discover/${productId}`)
      .then((res) => {
        if (res) {
          dispatch(discoverSuccess(res.data));
        }
      })
      .catch((err) => {
        dispatch(
          toastOpen({
            isToastOpen: true,
            toastMessage: err.message,
            toastVariant: "error",
          })
        );
      });
  };
};
