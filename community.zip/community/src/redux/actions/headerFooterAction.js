import axios from "axios";
import * as actions from 'redux/constant/types'
import { baseUrl } from "core/utils";
import { toastOpen } from "redux/actions/toastAction";

// Footer static json structure
const footerStatic = {
  "footerItems": [
      {
          "id": "6a687c10-5c7a-11eb-9e1e-cf3e549c3962",
          "primaryHeading": "Information",
          "utilityLinks" : [{
              "id": "6a687c10-5c7a-11eb-9e1e-cf3e549c392",
              "secondaryHeading":"About us",
              "path": "/AboutUs"
          },{
              "id": "a687c10-5c7a-11eb-9e1e-cf3e549c962",
              "secondaryHeading":"Blog",
              "path": "/Blog"
          },{
              "id": "6687c10-5c7a-11eb-9e1e-cf3e549c3962",
              "secondaryHeading":"Events",
              "path": "/Events"
          },{
              "id": "6a687c10-7a-11eb-9e1e-cf3e549c3962",
              "secondaryHeading":"FAQ",
              "path": "/FAQ"
          }]
      },
      {
          "id": "be2dcc10-5c7a-11eb-9168-931778d09dbc",
          "primaryHeading": "Helpful Links",
          "utilityLinks" : [{
              "id": "687c0-5c7a-11eb-9e1e-cf3e549c392",
              "secondaryHeading":"Services",
              "path": "/Services"
          },{
              "id": "687c0-5c7a-11eb-9e1e-cf3e9c392",
              "secondaryHeading":"Supports",
              "path": "/Supports"
          },{
              "id": "687c0-5c7a-11eb-9ee-cf3e549c392",
              "secondaryHeading":"Terms & Condition",
              "path": "/Termsa&Condition"
          },{
              "id": "687c0-5c7a-11e9e1e-cf3e549c392",
              "secondaryHeading":"Privacy Policy",
              "path": "/PrivacyPolicy"
          }]
      },
      {
          "id": "ca7e4350-5c7a-11eb-9e1e-cf3e549c3962",
          "primaryHeading": "Contact us",
          "utilityLinks" : [{
              "id": "687c0-5c7a-11eb-9e1e-cf3e549c392",
              "secondaryHeading":"1800-572-7626",
              "path": ""
          },{
              "id": "687c0-5c7a-11eb-9e1e-cf3e9392",
              "secondaryHeading":"service.in@poco.net",
              "path": "service.in@poco.net"
          }]
      }
  ]
}
// Header action start
export const menuItemsSucess = (res) => ({
  type: actions.MENU_ITEMS_SUCCESS,
  payload: res,
});

export const getMenuItems = () => {
  return (dispatch) => {
    axios
      .get(`${baseUrl}/header`)
      .then((res) => {
        dispatch(menuItemsSucess(res.data.headerMenu));
      })
      .catch((err) =>
        dispatch(
          toastOpen({
            isToastOpen: true,
            toastMessage: err.message,
            toastVariant: "error",
          })
        )
      );
  };
};

// Footer action start
export const footerItemsLoad = (load) => ({
  type: actions.FOOTER_ITEMS_LOAD,
  payload: load,
});

export const footerItemsSucces = (res) => ({
  type: actions.FOOTER_ITEMS_SUCCESS,
  payload: res,
});


export const getFooterItems = () => {
  return (dispatch) => {
    dispatch(footerItemsSucces(footerStatic.footerItems));
    // axios
    //   .get(`${baseUrl}/footer`)
    //   .then((res) => {
    //     dispatch(footerItemsSucces(footerStatic.footerItems));
    //   })
    //   .catch((err) => {
    //     dispatch(
    //       toastOpen({
    //         isToastOpen: true,
    //         toastMessage: err.message,
    //         toastVariant: "error",
    //       })
    //     );
    //   });
  };
};
