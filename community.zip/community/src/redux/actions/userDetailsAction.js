import axios from "axios";
import * as actions from "redux/constant/types";
import { baseUrl } from "core/utils";
import { toastOpen } from "redux/actions/toastAction";

//  user infromation action start
export const userDetailsLoad = () => ({
    type: actions.USER_DETAILS_LOAD,
  });
  
  export const userDetailsSuccess = (res) => ({
    type: actions.USER_DETAILS_SUCCESS,
    payload: res,
  });
  
  export const getProfileDetailsneew = (userType) => {
    console.log("coming right")
    return (dispatch) => {
      dispatch(userDetailsLoad());
      axios
        .get(`${baseUrl}/userProfileDetails`)
        .then((res) => {
          if (res) {
            dispatch(userDetailsSuccess(res.data));
          }
          console.log("items coming from redu", res)
        })
        .catch((err) => {
          dispatch(
            toastOpen({
              isToastOpen: true,
              toastMessage: err.message,
              toastVariant: "error",
            })
          );
        });
    };
  };