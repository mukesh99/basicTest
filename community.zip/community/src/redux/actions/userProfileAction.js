import axios from "axios";
import * as actions from "redux/constant/types";
import { baseUrl } from "core/utils";
import { toastOpen } from "redux/actions/toastAction";

//  user infromation action start
export const userProfileLoad = () => ({
  type: actions.USER_PROFILE_LOAD,
});

export const userProfileSuccess = (res) => ({
  type: actions.USER_PROFILE_SUCCESS,
  payload: res,
});

export const getUserProfile = (userType) => {
  return (dispatch) => {
    dispatch(userProfileLoad());
    axios
      .get(`${baseUrl}/profile/${userType}`)
      .then((res) => {
        if (res) {
          dispatch(userProfileSuccess(res.data));
        }
      })
      .catch((err) => {
        dispatch(
          toastOpen({
            isToastOpen: true,
            toastMessage: err.message,
            toastVariant: "error",
          })
        );
      });
  };
};

//  trending users action start
export const rakingUsersLoad = () => ({
  type: actions.RANKING_USERS_LOAD,
});

export const rakingUsersSuccess = (res) => ({
  type: actions.RANKING_USERS_SUCCESS,
  payload: res,
});

export const getTopRakingUsers = () => {
  return (dispatch) => {
    dispatch(rakingUsersLoad());
    axios
      .get(`${baseUrl}/topranking`)
      .then((res) => {
        if (res) {
          dispatch(rakingUsersSuccess(res.data));
        }
      })
      .catch((err) => {
        dispatch(
          toastOpen({
            isToastOpen: true,
            toastMessage: err.message,
            toastVariant: "error",
          })
        );
      });
  };
};
