import axios from "axios";
import * as actions from "redux/constant/types";
import { baseUrl } from "core/utils";
import { toastOpen } from "redux/actions/toastAction";

//  User page action start
export const userItemsLoad = () => ({
  type: actions.USER_ITEMS_LOAD,
});

export const userItemsSucces = (res) => ({
  type: actions.USER_ITEMS_SUCCESS,
  payload: res,
});

export const getUserItems = () => {
  return async (dispatch) => {
    dispatch(userItemsLoad());
    await axios
      .get(`${baseUrl}/user`)
      .then((res) => {
        //console.log("items coming", res)
        if (res) {
          dispatch(userItemsSucces(res.data));
        }
      })
      .catch((err) => {
        dispatch(toastOpen({
          isToastOpen: true,
          toastMessage: err.message,
          toastVariant: "error",
        }));
      });
  };
};