
import * as actions from "redux/constant/types";

export const triggerToast = (res) => ({
  type: actions.TOAST_OPEN,
  payload: res,
});

export const toastOpen = (payload) => {
  return (dispatch) => {
    dispatch(triggerToast(payload));
  };
};
