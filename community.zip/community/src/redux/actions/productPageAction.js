import axios from "axios";
import * as actions from "redux/constant/types";
import { baseUrl } from "core/utils";
import { toastOpen } from "redux/actions/toastAction";

//  Product page action start
export const productLoad = () => ({
  type: actions.PRODUCT_SERIES_LOAD,
});

export const productSuccess = (res) => ({
  type: actions.PRODUCT_SERIES_SUCCESS,
  payload: res,
});

export const getProduct = (productId) => {
  return async (dispatch) => {
    dispatch(productLoad());
   await axios
      .get(`${baseUrl}/product/${productId}`)
      .then((res) => {
        if (res) {
          dispatch(productSuccess(res.data));
        }
      })
      .catch((err) => {
        dispatch(
          toastOpen({
            isToastOpen: true,
            toastMessage: err.message,
            toastVariant: "error",
          })
        );
      });
  };
};
