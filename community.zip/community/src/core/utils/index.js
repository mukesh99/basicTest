//   APi Base URl
export const baseUrl = "http://localhost:30001";

//  Funtion to import image or icons from static folder
function importAll(r) {
  let images = {};
  r.keys().forEach((item, index) => {
    images[item.replace("./", "")] = r(item);
  });
  return images;
}

export const Iconsimport = importAll(
  require.context("static/icons", false, /\.(png|jpe?g|svg)$/)
);

export const Imagesimport = importAll(
  require.context("static/images", false, /\.(png|jpe?g|svg)$/)
);

//To detect moobile device
export const isMobile = [
  "Android",
  "iPhone",
  "SymbianOS",
  "Windows Phone",
  "iPad",
  "iPod",
].some((item) =>
  navigator.userAgent.toUpperCase().includes(item.toUpperCase())
);


export const validateEmailPassword = (statevalue,formValue) =>{
  if(formValue.email && formValue.email !== ""){
      //validate Email 
    let emailPattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
    let passwordPattern = new RegExp(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,32}$/gm);
    let tempState ={...statevalue}

    if(!emailPattern.test(formValue.email)){
      tempState.isValidEmail = true;
      tempState.errorEmailhelpertext = "Invalid email address";

    }else{ 
      tempState.isValidEmail = false;
      tempState.errorEmailhelpertext = "";
    }
    //validate Password     
    if(!passwordPattern.test(formValue.password)){ 
      tempState.isPasswordValid = true;
      tempState.errorPasswordhelpertext = "Invalid password"
    }
    else{ 
      tempState.isPasswordValid = false;
      tempState.errorPasswordhelpertext = ""
    }
    
    if(tempState.isValidEmail === false && tempState.isPasswordValid === false)  return formValue
    
    return tempState
} 
return null
}

