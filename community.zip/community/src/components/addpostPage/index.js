import React, { useState, useRef } from "react";
import { PostEditor } from "../elements/postEditor";
import {
  Box,
  Grid,
  Typography,
  Button,
  TextField,
  Paper,
  FormControl,
  Select,
  MenuItem,
  ListSubheader,
} from "@material-ui/core";
import "./index.scss";

export default function UseraddPost() {
  const [selctBoxValue, setSelctBoxValue] = useState({});
  const [uploadPostThumbnail, setuploadPostThumbnail] = useState("");
  const [postTitle, setPostTitle] = useState("");
  const [postEditorValue, setPostEditorValue] = useState("");
  let getPostvalue = useRef();
  let postPreview = useRef();

  // Method on change editor data seting to state
  const editContent = (content) => {
    // const check = editor.getContents(content);
    setPostEditorValue(content);
  };

  // Method to upload Cover image
  const uploadpostThumbnail = ({ target }) => {
    let imagebase64 =""
    var file = target.files[0];  
    // converting thumbnail image to base64 string 
    var reader = new FileReader();  
    reader.onloadend = function() {  
        imagebase64 = reader.result;  
        setuploadPostThumbnail(imagebase64);
    }  
    reader.readAsDataURL(file); 
  };

  // Method to get post editor value
  const postSubmit = () => {
    const editor = getPostvalue.current.getEditor();
    const unprivilegedEditor = getPostvalue.current.makeUnprivilegedEditor(
      editor
    );
    // unprivilegedEditor.getHTML() to get editor content as HTML
    postPreview.current.innerHTML = postEditorValue;
    const postContent = unprivilegedEditor.getHTML();
    const tagData = [];
    const postData = {
      postThumbnail: uploadPostThumbnail,
      postTitle: postTitle,
      postAvatar: "",
      postUserName: "",
      postUserLastSeen: "",
      postViews: "",
      postLikes: "",
      postComments: "",
      startDate: "",
      endDate: "",
      tagName: "",
      postContent: postContent,
      category: selctBoxValue,
    };
    tagData.push(postData);
    // finalObjecttoPost Object will be push to API
    const finalObjecttoPost = {
      tagData: tagData,
    };
    console.log(finalObjecttoPost);
  };

  const slectCategory = function (event) {
    setSelctBoxValue({
      ...selctBoxValue,
      name: event.target.value,
    });
  };

  // Cover image upload component
  const renderThumbnailUpload = () => {
    return (
      <Grid
        container
        className="add-post-thumbnail"
        direction="row"
        justify="center"
        alignItems="center"
      >
        <Grid item md={8}>
          <Grid container>
            <Grid item md={6}>
              <Box
                p={3}
                display="flex"
                flexDirection="column"
                alignItems="center"
                justifyContent="center"
                className="upload-container"
              >
                <Typography variant="h5">Cover Image</Typography>
                <Box mt={1} p={3} pt={4} pb={4} className="upolad-thumbnail">
                  <input
                    accept="image/x-png,image/jpeg"
                    style={{ display: "none" }}
                    id="contained-button-file"
                    multiple
                    type="file"
                    onChange={(e) => uploadpostThumbnail(e)}
                  />
                  <label htmlFor="contained-button-file">
                    <Button
                      variant="contained"
                      color="secondary"
                      component="span"
                      size="large"
                    >
                      Upload
                    </Button>
                  </label>
                </Box>
              </Box>
            </Grid>
            <Grid item md={6}>
              <Paper>
                <Box height="194px">
                <Grid container>
                  <Grid item md={12}>
                    <Box p={2} display="flex" flexDirection="row" justifyContent="center">
                      <Typography variant="subtitle1">
                        Select your post categorize
                      </Typography>
                    </Box>
                  </Grid>
                  <Grid item md={10}>
                    <Box pl={3} display="flex" alignItems="center">
                      <FormControl variant="outlined" fullWidth>
                        <Select
                          defaultValue="None"
                          id="grouped-select"
                          onChange={slectCategory}
                        >
                          <MenuItem value="">
                            <em>None</em>
                          </MenuItem>
                          <ListSubheader>Category 1</ListSubheader>
                          <MenuItem value="Option 1">Products</MenuItem>
                          <MenuItem value="Option 2">MIUI</MenuItem>
                          <ListSubheader>Category 2</ListSubheader>
                          <MenuItem value="Option 3">All Post</MenuItem>
                          <MenuItem value="Option 4">Post</MenuItem>
                        </Select>
                      </FormControl>
                    </Box>
                  </Grid>
                </Grid>
                </Box>
              </Paper>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    );
  };

  const postEditorHeader = (
    <Box display="flex" p={3} className="save-post-section">
      <Grid container>
        <Grid item xs={6} sm={6} md={6}>
          <Typography variant="h5" color="secondary">
            Add post
          </Typography>
        </Grid>
        <Grid item xs={6} sm={6} md={6}>
          <Box display="flex" justifyContent="flex-end" alignItems="center">
            <Box mr={3}>
              <Button>Save</Button>
            </Box>
            <Box>
              <Button variant="outlined" onClick={postSubmit}>Post</Button>
            </Box>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );

  return (
    <React.Fragment>
      <Box mt={8}>
        <Grid container justify="center" className="post-container">
          <Grid item xs={12} sm={12} md={12}>
            {postEditorHeader}
          </Grid>
          <Grid item xs={10} sm={10} md={10}>
            <div className="post-form">
              {renderThumbnailUpload()}
              <TextField
                id="post-title"
                label="Type your title here…"
                size="medium"
                variant="filled"
                onChange={(e) => setPostTitle(e.target.value)}
                fullWidth
              />
              <PostEditor
                postRef={getPostvalue}
                content={postEditorValue}
                contentUpdate={editContent}
              />
            </div>
            <Typography variant="h5">Post preview</Typography>
            {/* <div dangerouslySetInnerHTML={{ __html: text }}></div> */}
            <div className="ql-editor">
              <div ref={postPreview}></div>
            </div>
          </Grid>
        </Grid>
      </Box>
    </React.Fragment>
  );
}
