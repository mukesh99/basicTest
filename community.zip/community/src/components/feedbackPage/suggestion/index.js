import React from "react";
import {
  Box,
  Button,
  Typography,
  Paper,
  TextField,
} from "@material-ui/core";

export default function Suggestion() {
  return (
    <React.Fragment>
      <Box bgcolor="text.primary" p={3} >
        <Typography variant="h4" color="secondary">
          <strong>
            Feature <br />
            Suggestion
          </strong>
        </Typography>
      </Box>
      <Paper>
        <Box className="section-container">
          <form autoComplete="off">
            <Box>
              <Typography variant="subtitle2"><strong>Subject</strong></Typography>
              <TextField id="Subject" variant="outlined" fullWidth />
            </Box>
            <Box mt={2}>
              <Typography variant="subtitle2"><strong>Comment</strong></Typography>
              <TextField
                id="Comment"
                variant="outlined"
                multiline
                rows={4}
                fullWidth
              />
            </Box>
            <Box mt={5} width="100%" justifyContent="center" textAlign="center">
              <Button variant="contained" color="primary" size="large">Post</Button>
            </Box>
          </form>
        </Box>
      </Paper>
    </React.Fragment>
  );
}
