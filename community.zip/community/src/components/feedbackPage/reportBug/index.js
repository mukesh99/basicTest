import React from "react";
import { Box, Button, Typography, Paper, TextField } from "@material-ui/core";

export default function ReportBug() {
  return (
    <React.Fragment>
      <Box bgcolor="text.primary" p={3} >
        <Typography variant="h4" color="secondary">
          <strong>
            Report Bug & <br />
            Feedback
          </strong>
        </Typography>
      </Box>
      <Paper>
        <Box className="section-container">
          <form autoComplete="off">
            <Box>
              <Typography variant="subtitle2">
                <strong>Subject</strong>
              </Typography>
              <TextField id="Subject" variant="outlined" fullWidth />
            </Box>
            <Box mt={2}>
              <Typography variant="subtitle2">
                <strong>Comment</strong>
              </Typography>
              <TextField
                id="Comment"
                variant="outlined"
                multiline
                rows={4}
                fullWidth
              />
            </Box>
            <Box mt={2} className="feedback-upload">
              <Typography variant="subtitle2">
                <strong>Resource: Image or Zip max 50MB</strong>
              </Typography>
              <input
                accept="image/*"
                id="contained-button-file"
                multiple
                type="file"
                style={{'display':'none'}}
              />
              <label htmlFor="contained-button-file">
                <Button variant="contained" color="default" component="span">
                  Upload
                </Button>
              </label>
            </Box>
            <Box mt={5} width="100%" justifyContent="center" textAlign="center">
              <Button variant="contained" color="primary" size="large">
                Send
              </Button>
            </Box>
          </form>
        </Box>
      </Paper>
    </React.Fragment>
  );
}
