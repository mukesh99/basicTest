import React from "react";
import { Box, Button, Typography, Paper, TextField } from "@material-ui/core";

export default function VotePoll() {
  return (
    <React.Fragment>
      <Box bgcolor="text.primary" p={3} >
        <Typography variant="h4" color="secondary">
          <strong>Vote Poll</strong>
        </Typography>
      </Box>
      <Paper>
        <Box className="section-container">
          <form autoComplete="off">
            <Box>
              <Typography variant="subtitle2">
                <strong>Type Vote Poll Question</strong>
              </Typography>
              <TextField id="Subject" variant="outlined" fullWidth />
            </Box>
            <Box mt={2}>
              <Typography variant="subtitle2">
                <strong>Option 1</strong>
              </Typography>
              <TextField id="Subject" variant="outlined" fullWidth />
            </Box>
            <Box mt={2}>
              <Typography variant="subtitle2">
                <strong>Option 2</strong>
              </Typography>
              <TextField id="Subject" variant="outlined" fullWidth />
            </Box>
            <Box mt={2}>
              <Typography variant="subtitle2">
                <strong>Option 3</strong>
              </Typography>
              <TextField id="Subject" variant="outlined" fullWidth />
            </Box>
            <Box mt={5} width="100%" justifyContent="center" textAlign="center">
              <Button variant="contained" color="primary" size="large">
                Send
              </Button>
            </Box>
          </form>
        </Box>
      </Paper>
    </React.Fragment>
  );
}
