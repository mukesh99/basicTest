import React, { useState } from "react";
// Matrial element
import { Grid, Box, Button } from "@material-ui/core";
import Suggestion from "./suggestion/index";
import VotePoll from "./votePoll";
import ReportBug from "./reportBug";
import { AddPost } from "components/elements/addPost";
import "./index.scss";

export default function FeedbackPage() {
  const [sectionIndex, SetsectionIndex] = useState(0);
  const switchSection = (currentSection) => {
    SetsectionIndex(currentSection);
  };

  return (
    <React.Fragment>
      <Grid container>
        <Grid item xs={12} sm={10} md={8}>
          <Box
            mt={12}
            ml={2}
            mr={3}
            mb={4}
            // display={sectionIndex === 0 ? "block" : "none"}
            className="navigate-section"
          >
            <Grid
              container
              justify="center"
              alignContent="space-between"
              alignItems="center"
              spacing={5}
            >
              <Grid item xs={12} sm={4} md={4}>
                <Button
                  variant="contained"
                  color="primary"
                  name="suggestions"
                  size="large"
                  onClick={() => switchSection(1)}
                  fullWidth
                >
                  Share Suggestion
                </Button>
              </Grid>
              <Grid item xs={12} sm={4} md={4}>
                <Button
                  variant="contained"
                  color="primary"
                  name="feedback"
                  size="large"
                  onClick={() => switchSection(2)}
                  fullWidth
                >
                  Add Feedback
                </Button>
              </Grid>
              <Grid item xs={12} sm={4} md={4}>
                <Button
                  variant="contained"
                  color="primary"
                  name="votepoll"
                  size="large"
                  onClick={() => switchSection(3)}
                  fullWidth
                >
                  Vote Poll
                </Button>
              </Grid>
            </Grid>
          </Box>
        </Grid>
        <Grid xs={12} sm={10} md={4}>
          <Box mt={12} display={sectionIndex === 0 ? "block" : "none"}>
            <AddPost />
          </Box>
        </Grid>
      </Grid>
      {/* feed back child components */}
      <Grid container justify="center" className="fedback-page">
        <Grid item xs={12} sm={10} md={10} justify="center">
          <Box display={sectionIndex === 1 ? "block" : "none"}>
            <Suggestion />
          </Box>
        </Grid>
        <Grid item xs={12} sm={10} md={10} justify="center">
          <Box display={sectionIndex === 2 ? "block" : "none"}>
            <VotePoll />
          </Box>
        </Grid>
        <Grid item xs={12} sm={10} md={10} justify="center">
          <Box display={sectionIndex === 3 ? "block" : "none"}>
            <ReportBug />
          </Box>
        </Grid>
      </Grid>
    </React.Fragment>
  );
}
