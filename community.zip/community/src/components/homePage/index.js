import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getHomeItems, getTrendingItems, getAllpostItems } from "redux/actions/homePageAction";
import Backdrop from "@material-ui/core/Backdrop";
import CircularProgress from "@material-ui/core/CircularProgress";
import HomeTabSection from "./TabSection";
import { homeTabStyle, pageLoaderStyle } from "core/theme/makeStyle";
import "./index.scss";

export default function HomePage() {
  const classes = pageLoaderStyle();
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getHomeItems());
    dispatch(getTrendingItems());
    dispatch(getAllpostItems());
  }, [dispatch]);

  const { homeItems, homeItemsLoad, trendingAndfeatureItems } = useSelector(
    (state) => state.homePageItems
  );

  //  Banner section image
  const bannerImg = homeItems && homeItems.home.bannerImg;

  // page loader
  const pageLoader = (
    <Backdrop className={classes.backdrop} open={homeItemsLoad}>
      <CircularProgress color="inherit" />
    </Backdrop>
  );
  return (
    <div className="poco-home">
      <img src={bannerImg} alt="home-banner" width="100%" height="600px" />
      <HomeTabSection ItemList={homeItems} homeTabStyle={homeTabStyle} {...trendingAndfeatureItems}/>
      {pageLoader}
    </div>
  );
}
