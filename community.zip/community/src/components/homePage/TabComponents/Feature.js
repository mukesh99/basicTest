import React from "react";
import { PocoCard } from "components/elements/cards";
import {AddPost} from "components/elements/addPost"
import { Grid } from "@material-ui/core";

export const Feature = (props) => {
  const { featureData } = props;

  const renderFeature = () => {
    return (
      <React.Fragment>
        {featureData?.map((ele) =>
          ele.tagData.map((element) => (
            <Grid item md={6}>
              <PocoCard
                Img={element.postThumbnail}
                Tittle={element.postTitle}
                ProfilePic={element.postAvatar}
                UserName={element.postUserName}
                lastSeen={element.postUserLastSeen}
                tag={element.tagName}
                view={element.postViews}
                like={element.postLikes}
              />
            </Grid>
          ))
        )}
      </React.Fragment>
    );
  };
  return (
    <React.Fragment>
      <Grid container spacing={3}>
        <Grid item xs={12} sm={8} md={8}>
          <Grid container spacing={3}>
            {renderFeature()}
          </Grid>
        </Grid>
        <Grid item xs={12} sm={4} md={4}>
            <AddPost/>
        </Grid>
      </Grid>
    </React.Fragment>
  );
};
