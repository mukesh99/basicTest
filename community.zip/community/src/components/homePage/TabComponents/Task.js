import React from "react";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Grid } from "@material-ui/core";
import { getallTaskItems } from "redux/actions/taskAction";

export const Alltask = (props) => {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(getallTaskItems());
      }, [dispatch]);

      const { alltask } = useSelector(
        (state) => state.taskPageItems
      );
      
      //const { alltaskLoad } = useSelector((state) => state.taskPageItems);
     
     const taskinfo = alltask && alltask.taskdetails && alltask.taskdetails[0] || {};
     console.log("alltaskLoad123", taskinfo)

  
  return (
    <React.Fragment>
      <Grid container spacing={3}>
        <Grid item xs={12} sm={12} md={12}>
          <Grid container spacing={3}>
            <div className="taskarea">
              <div className="title">Tasks</div>
              <div className="subtitle">{taskinfo.title}</div>
              </div>
          {taskinfo.tagData && taskinfo.tagData.map((alldata) => (
            <Grid item md={3}>
              <div className="taskimg"><img src={`http://placeimg.com/640/480/food`} className="taskimg" /></div>
              <div className="tasktext">{alldata.taskname}</div>
            </Grid>
          ))}
          </Grid>
        </Grid>
       
      </Grid>
    </React.Fragment>
  );
};
