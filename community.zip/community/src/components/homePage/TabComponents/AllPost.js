import React from "react";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { PocoCard } from "components/elements/cards";
import {AddPost} from "components/elements/addPost"
import { Grid } from "@material-ui/core";
import { getAllpostItems } from "redux/actions/homePageAction";

export const Allpost = (props) => {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(getAllpostItems());
      }, [dispatch]);

      const { allpostItems } = useSelector(
        (state) => state.homePageItems
      );
     //console.log("allpostItems", allpostItems)

  const renderAllpost = () => {
    return (
      <React.Fragment>
        {allpostItems.allPost?.map((ele) =>
          ele.tagData.map((element) => (
            <Grid item md={6}>
              <PocoCard
                Img={element.postThumbnail}
                Tittle={element.postTitle}
                ProfilePic={element.postAvatar}
                UserName={element.postUserName}
                lastSeen={element.postUserLastSeen}
                tag={element.tagName}
                view={element.postViews}
                like={element.postLikes}
              />
            </Grid>
          ))
        )}
      </React.Fragment>
    );
  };
  return (
    <React.Fragment>
      <Grid container spacing={3}>
        <Grid item xs={12} sm={8} md={8}>
          <Grid container spacing={3}>
            {renderAllpost()}
          </Grid>
        </Grid>
        <Grid item xs={12} sm={4} md={4}>
            <AddPost/>
        </Grid>
      </Grid>
    </React.Fragment>
  );
};
