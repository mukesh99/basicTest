import React from "react";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getUserItems} from "redux/actions/userAction";
import { homeTabStyle, pageLoaderStyle } from "core/theme/makeStyle";
import { PocoCard } from "components/elements/cards";
import { Grid } from "@material-ui/core";
import "./user.scss";

export default function UserPage(){
        const dispatch = useDispatch();
        useEffect(() => {
            dispatch(getUserItems());
          }, [dispatch]);


    // Global state call
  const { userItemsLoad, userItems } = useSelector(
    (state) => state.user
  );
  console.log("user part", userItems)
  const userinfo = userItems && userItems.userDetails && userItems.userDetails[0] || {};
  
  //console.log("hi",userItems)
  const renderUser = () => {
    return (
      <React.Fragment>
        {userinfo.tagData && userinfo.tagData.map((alldata) => (
            <Grid item md={4} key={alldata.id}>
              <PocoCard
                Img={alldata.postAvatar}
                UserName={alldata.postUserName}
                NoofDays={alldata.noofDay}
                PostDec={alldata.postDesc}
                PostReply={alldata.postReply}
              />
            </Grid>
           ))}
      </React.Fragment>
    );
  };
    return (
        <div>{renderUser()}</div>
    )
}
