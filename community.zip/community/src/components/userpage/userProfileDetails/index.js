import React from "react";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getProfileDetailsneew} from "redux/actions/userDetailsAction";
import { homeTabStyle, pageLoaderStyle } from "core/theme/makeStyle";
import { UserDetails } from "components/elements/cards/userDetailsCart";
import { Grid, Box } from "@material-ui/core";
import { AddPost } from "components/elements/addPost";

export default function UserProfileDetailsnew(){
        const dispatch = useDispatch();
        useEffect(() => {
            dispatch(getProfileDetailsneew());
            console.log("getprofile",getProfileDetailsneew() )
          }, [dispatch]);


    // Global state call
    
    const { userDetails } = useSelector((state) => state.userDetails);
 // console.log("hi", userDetails)
  const userinfo = userDetails && userDetails.trending && userDetails.trending[0] || {};
  


  const renderUser = () => {
    return (
      <React.Fragment>
        {userinfo.tagData && userinfo.tagData.map((alldata) => (
            <Grid item md={6} key={alldata.id}>
              <UserDetails
                Img={alldata.postThumbnail}
                Tittle={alldata.postTitle}
                ProfilePic={alldata.postAvatar}
                UserName={alldata.postUserName}
                lastSeen={alldata.postUserLastSeen}
                PostReply={alldata.postReply}
                tag={alldata.tagName}
                view={alldata.postViews}
                like={alldata.postLikes}
                
              />
            </Grid>
           ))}
           
          
      </React.Fragment>
    );
  };
    return (
      <div className="product-page">
        
        
      <Box mt={10} mb={2} p={3}>
        <Grid container component="span" spacing={5}>
          <Grid item xs={12} sm={12} md={8} component="span">
            <Grid container spacing={5} component="span">
            {renderUser()}
            </Grid>
          </Grid>
          <Grid item xs={12} sm={12} md={4} component="span">
            <AddPost />
          </Grid>
        </Grid>
      </Box>
    </div>
    )
}
