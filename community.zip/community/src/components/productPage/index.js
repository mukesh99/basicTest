import React, { useEffect } from "react";
// Redux selector
import { useDispatch, useSelector } from "react-redux";
// Matrial element
import { Grid, Box } from "@material-ui/core";

import { AddPost } from "components/elements/addPost";
import PorductList from "./postList";
// Redux action calls
import { getProduct } from "redux/actions/productPageAction";

import "./index.scss";

export default function ProductPage() {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getProduct());
  }, [dispatch]);

  // Get product object from redux state
  const { product } = useSelector((state) => state.product);
 
  return (
    <div className="product-page">
      <Box mt={10} mb={2} p={3}>
        <Grid container component="span" spacing={5}>
          <Grid item xs={12} sm={12} md={8} component="span">
            <Grid container spacing={5} component="span">
              <PorductList {...product}/>
            </Grid>
          </Grid>
          <Grid item xs={12} sm={12} md={4} component="span">
            <AddPost />
          </Grid>
        </Grid>
      </Box>
    </div>
  );
}
