import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Card,
  Avatar,
  Typography,
  CardMedia,
  CardContent,
  CardActions,
  CardActionArea,
  Box,
  GridListTileBar,
} from "@material-ui/core";
import PropTypes from "prop-types";
import { Iconsimport } from "core/utils";
import "./index.scss";

export function PocoCard(props) {
  const {
    Img,
    Tittle,
    ProfilePic,
    UserName,
    lastSeen,
    tag,
    view,
    like,
    height,
    isDark,
  } = props;

  const cardsStyle = makeStyles((theme) => ({
    root: {},
    media: {
      height: height || 200,
    },
  }));

  const classes = cardsStyle();

  const userAction =
    like !== undefined || view !== undefined;
  const cardConent = Tittle !== undefined;
  const cardAction =
    ProfilePic !== undefined ||
    UserName !== undefined ||
    lastSeen !== undefined ||
    tag !== undefined;
  return (
    <Card
      className={`${isDark && isDark ? "poco-card-dark" : "poco-card"} ${
        classes.root
      }`}
    >
      <CardActionArea>
        {userAction && (
          <GridListTileBar
            title={
              <Box display="flex" alignItems="center" p={1}>
                <img src={Iconsimport["view.svg"]} alt="view" />
                {view}
              </Box>
            }
            subtitle={
              <Box display="flex" alignItems="center" p={1}>
                <img src={Iconsimport["like.svg"]} alt="like" />
                {like}
              </Box>
            }
            actionIcon={
              <Box display="flex" alignItems="center" p={1}>
                <img
                  src={Iconsimport["bookmark.svg"]}
                  alt="bookmark"
                  onClick={() => console.log("bookmared action goes here")}
                />
              </Box>
            }
          />
        )}
        <CardMedia className={classes.media} image={Img} />
        {cardConent && (
          <CardContent>
            <Typography gutterBottom variant="h6">
              {Tittle}
            </Typography>
          </CardContent>
        )}
      </CardActionArea>
      {cardAction && (
        <CardActions>
          <Avatar src={ProfilePic} component="span" />
          <Box flexGrow={1} p={1} alignItems="center" component="span">
            <Typography
              gutterBottom
              variant="body1"
              component="span"
              className="text-secondary"
              display="block"
            >
              {UserName}
            </Typography>
            <Typography
              gutterBottom
              variant="body1"
              component="span"
              className="text-secondary"
            >
              {lastSeen}
            </Typography>
          </Box>
          <Box p={1} component="span">
            <Typography
              gutterBottom
              variant="h6"
              className="text-secondary"
              component="span"
            >
              <strong>{tag}</strong>
            </Typography>
          </Box>
        </CardActions>
      )}
    </Card>
  );
}

PocoCard.propTypes = {
  Img: PropTypes.string,
  Tittle: PropTypes.string,
  UserName: PropTypes.any,
  lastSeen: PropTypes.any,
  tag: PropTypes.string,
  view: PropTypes.any,
  like: PropTypes.any,
  height: PropTypes.number,
  isDark: PropTypes.bool,
};
