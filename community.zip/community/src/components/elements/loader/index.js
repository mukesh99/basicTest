import React from 'react'
import Backdrop from "@material-ui/core/Backdrop";
import CircularProgress from "@material-ui/core/CircularProgress";
import { pageLoaderStyle } from "../../../core/theme/makeStyle";

export function Loader (props){
    const { open } = props
    const classes = pageLoaderStyle();
    return (
        <Backdrop className={classes.backdrop} open={true}>
          <CircularProgress color="inherit" />
        </Backdrop>
    )
}