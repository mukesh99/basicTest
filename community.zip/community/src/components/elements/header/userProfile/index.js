import React from "react";
import { Link } from "react-router-dom";
import {
  Box,
  Grid,
  Paper,
  Typography,
  Avatar,
  Button,
} from "@material-ui/core";

export function UserProfile(props) {
  const { userInfo, isloggedIn, activity, topRakingUsers } = props;

  // user prfoile information
  const renderProfile = () => {
    return (
      <Paper className="profile-card">
        <Box display="flex" flexDirection="row">
          {userInfo && (
            <Box flexGrow={1} pl={5} p={3} className="card-lhs">
              <Avatar src={userInfo.profilePic} alt="profile pic" />
              <Typography variant="subtitle1" color="secondary" mt={2}>
                <strong>{userInfo.pocoTitle}</strong>
              </Typography>
              <Typography
                variant="subtitle1"
                color="inherit"
                className="text-white"
              >
                <strong>
                  {userInfo.firstName} {userInfo.lastName}
                </strong>
              </Typography>
            </Box>
          )}
          <Box flexGrow={1} p={4} className="card-rhs">
            {activity &&
              activity.map((items) => (
                <React.Fragment>
                  <Typography variant="subtitle1">
                    <strong>{items.numberofPost} Posted</strong>
                  </Typography>
                  <Typography variant="subtitle1">
                    <strong>
                      {items.numberofTaskCompleted} Tasked Completed
                    </strong>
                  </Typography>
                  <Typography variant="subtitle1">
                    <strong> {items.numberofBookMark} Bookmaked</strong>
                  </Typography>
                </React.Fragment>
              ))}
          </Box>
        </Box>
      </Paper>
    );
  };
  //   Static profile menu
  const renderProfileMenu = () => {
    return (
      <React.Fragment>
        {isloggedIn ? (
          <Box
            display="flex"
            alignItems="flex-end"
            flexDirection="column"
            className="profile-navigation"
          >
            {userInfo && (
              <Typography variant="subtitle1">
                {userInfo.firstName} {userInfo.lastName}
              </Typography>
            )}
            <Typography variant="h6">
              <Link to="profile">
                <strong>Profile</strong>
              </Link>
            </Typography>
            <Typography variant="h6">
              <Link to="Post">
                <strong>Post</strong>
              </Link>
            </Typography>
            <Typography variant="h6">
              <Link to="Tasks">
                <strong>Tasks</strong>
              </Link>
            </Typography>
            <Typography variant="h6">
              <Link to="Settings">
                <strong>Settings</strong>
              </Link>
            </Typography>
            <Typography variant="subtitle1">
              <Link to="login">Logout</Link>
            </Typography>
          </Box>
        ) : (
          <Box
            display="flex"
            alignItems="flex-end"
            flexDirection="column"
            className="profile-navigation"
          >
            <Typography variant="subtitle1">Welcome</Typography>
            <Typography variant="h6">
              <Link to="Signup">
                <strong>Sign up</strong>
              </Link>
            </Typography>
            <Typography variant="subtitle1">
              <Link to="login">Login</Link>
            </Typography>
          </Box>
        )}
      </React.Fragment>
    );
  };
  // top raking user section
  const renderTopRankingUsers = () => {
    return (
      <div className="top-ranking-users-section">
        {topRakingUsers?.map((users) => (
          <Paper>
            <Box display="flex" alignItems="center" mb={1}>
              <Box
                display="flex"
                flexGrow={1}
                p={1}
                className="users-lhs"
                alignItems="center"
              >
                <Typography variant="body1">#{users.ranking}</Typography>
                <Avatar src={users.profilePic} alt="trending user pic" />
                <Typography variant="subtitle1">{users.firstName}</Typography>
                <Typography variant="subtitle1">{users.lastName}</Typography>
              </Box>
              <Box className="follow-rhs">
                <Button>Follow</Button>
              </Box>
            </Box>
          </Paper>
        ))}
      </div>
    );
  };
  return (
    <div className="">
      <Grid container justify="center" alignItems="center">
        <Grid item xs={12} md={10}>
          <Grid container spacing={6}>
            <Grid item xs={6} md={9}>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  {isloggedIn && renderTopRankingUsers()}
                </Grid>
                <Grid item xs={12} md={6}>
                  {isloggedIn && renderProfile()}
                </Grid>
              </Grid>
            </Grid>
            <Grid item xs={6} md={3}>
              {renderProfileMenu()}
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </div>
  );
}
