import React, { useState } from "react";
import { AppBar, Box, Typography } from "@material-ui/core";
import { HoverMenu } from "components/elements/hoverMenu";
import { Iconsimport } from "core/utils";
import { UserProfile } from "../userProfile";

export default function MobileAppBar(props) {

  const [hoverMenu, setHoverMenu] = useState(false);
  // Hover menu close
  const hoverMenuClose = () => {
    setHoverMenu(false);
  };
  const hoverMenuOpen =()=> {
    setHoverMenu(!hoverMenu);
  }
  const renderMobileAppBar = (
    <Box
    display={{
      xs: "block",
      sm: "none",
      md: "none",
      lg: "none",
      xl: "none",
    }}
  >
    {/* User profile for mobile view */}
     <HoverMenu anchor='bottom' hover={hoverMenu} close={hoverMenuClose}>
        <UserProfile {...props}/>
      </HoverMenu>
    <AppBar
      position="fixed"
      color="primary"
      style={{ top: "auto", bottom: "0" }}
    >
      <Box
        display="flex"
        p={2}
        justifyContent="space-around"
        alignItems="center"
        className="appbar-icons"
      >
        <Box textAlign="center">
          <img src={Iconsimport["tasks.svg"]} alt="taks" />
          <Typography variant="body2">Tasks</Typography>
        </Box>
        <Box textAlign="center">
          <img src={Iconsimport["calendar.svg"]} alt="taks" />
          <Typography variant="body2">Calendar</Typography>
        </Box>
        <Box textAlign="center">
          <img src={Iconsimport["post.svg"]} alt="taks" />
          <Typography variant="body2">Post</Typography>
        </Box>
        <Box textAlign="center" onClick={hoverMenuOpen}>
          <img src={Iconsimport["user.svg"]} alt="taks" />
          <Typography variant="body2" >User</Typography>
        </Box>
        <Box textAlign="center" >
          <img src={Iconsimport["menu.svg"]} alt="taks" />
          <Typography variant="body2">Menu</Typography>
        </Box>
      </Box>
    </AppBar>
  </Box>
  )
  return (
    <React.Fragment>
      {renderMobileAppBar}
    </React.Fragment>
  );
}
