import React from "react";
import { Box, Grid, OutlinedInput, InputAdornment,IconButton } from "@material-ui/core";
import SearchIcon from "@material-ui/icons/Search";
import CloseIcon from "@material-ui/icons/Close";
export default function SearchBar(props) {
  return (
    <React.Fragment>
      <Box display="flex" justifyContent="flex-end">
      <IconButton color="secondary">
        <CloseIcon onClick={props.close} />
      </IconButton>
      </Box>
      <Grid
        container
        justify="center"
        alignItems="center"
        className="search-bar"
      >
        <Grid item md={6}>
          <OutlinedInput
            id="search"
            type="text"
            startAdornment={
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            }
            labelWidth={70}
            fullWidth
            color="secondary"
            placeholder="Type here to search"
          />
        </Grid>
      </Grid>
    </React.Fragment>
  );
}
