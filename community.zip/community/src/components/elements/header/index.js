import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
// Material ui embaded style
import { HeaderStyle } from "core/theme/makeStyle";
// Redux action calls
import { getMenuItems } from "redux/actions/headerFooterAction";
import {
  getUserProfile,
  getTopRakingUsers,
} from "redux/actions/userProfileAction";
// Child components
import MobileAppBar from "./mobileAppbar";
import SearchBar from "./searchBar";
// Reusable component
import { HoverMenu } from "../hoverMenu";
import { UserProfile } from "./userProfile";
// Material ui icons
import { Iconsimport, Imagesimport } from "core/utils";
import SearchIcon from "@material-ui/icons/Search";

import "./index.scss";
// Material ui elements
import {
  AppBar,
  Toolbar,
  IconButton,
  Typography,
  Box,
  Grid,
} from "@material-ui/core";

export default function Header() {
  const dispatch = useDispatch();
  const classes = HeaderStyle();
  const [hoverMenu, setHoverMenu] = useState(false);
  const [profileHover, setProfileHover] = useState(false);
  const [isSearchOpen, setSearchOpen] = useState(false);
  const [getMenuId, setMenuId] = useState({ id: "", path: "" });

  useEffect(() => {
    dispatch(getMenuItems());
    dispatch(getUserProfile(1234));
    dispatch(getTopRakingUsers());
  }, [dispatch]);

  // Hover menu open
  const hoverMenuOpen = (id, path) => (event) => {
    const urlPath = path.replace(/[^/]*$/, "");

    setHoverMenu(true);
    setProfileHover(false);
    setMenuId({ id: id, path: urlPath });
    setSearchOpen(false);
  };

  // Hover menu close
  const hoverMenuClose = () => {
    setHoverMenu(false);
  };

  // Hover profile open
  const hoverProfileOpen = (id) => (event) => {
    setProfileHover(true);
    setHoverMenu(false);
  };

  // Search bar open
  const handleSearchBar = (event) => {
    setSearchOpen(true);
    setProfileHover(false);
  };
  const handleSearchBarClose = () => {
    setSearchOpen(false);
  };

  // Hover profile close
  const hoverProfileClose = () => {
    setProfileHover(false);
  };

  // Menu hover passing data from local state
  const renderHoverMenuData = () => {
    // filtered data form array which maching to sate id
    const items = menuItems?.filter(
      (element) => element.id === getMenuId.id && element
    );
    const seriesName = Object.assign({}, ...items);
    const { subMenus } = seriesName;

    return (
      <Grid container className="product-series">
        <Grid item md={3}>
          {subMenus?.map((element) => (
            <Typography
              className={classes.title}
              key={element.id}
              variant="h6"
              noWrap
            >
              <strong>
                <Link to={`${getMenuId.path}${element.id}`}>
                  {element.name}
                </Link>
              </strong>
            </Typography>
          ))}
        </Grid>
        <Grid item md={3}>
          {/* <PocoCard
          Img={"http://placeimg.com/640/480/technics"}
          isDark={true}
          Tittle={getMenuId}
        /> */}
        </Grid>
      </Grid>
    );
  };

  // Global state call
  const { menuItems } = useSelector((state) => state.menuItem);
  const { userProfileLoad, userProfile, topRankingUsers } = useSelector(
    (state) => state.userProfile
  );

  // Header start
  const rednderAppBar = (
    <AppBar position="fixed" color="primary">
      <Toolbar>
        <Box display="flex" flexGrow={1}>
          <Typography className={classes.title} variant="h6" noWrap>
            <img
              src={Imagesimport["logo.png"]}
              alt="logo"
              className="header-logo"
            />
          </Typography>
        </Box>
        <Box
          width="50%"
          display="flex"
          textAlign="center"
          className="content-space d-none-xs"
          textOverflow="ellipsis"
        >
          {menuItems?.map((menu) => (
            <Typography
              variant="body2"
              color="inherit"
              key={menu.id}
              onMouseOver={
                menu.isHoverMenu ? hoverMenuOpen(menu.id, menu.path) : null
              }
            >
              <Link to={menu.path}>{menu.name}</Link>
            </Typography>
          ))}
        </Box>
        <div className={classes.grow} />
        <Box display="flex">
          <Box mr={2}>
            <IconButton
              edge="end"
              aria-haspopup="true"
              color="inherit"
            >
              <SearchIcon  onClick={handleSearchBar}/>
            </IconButton>
          </Box>
          <Box>
            <div className={classes.sectionDesktop}>
              <IconButton
                edge="end"
                aria-haspopup="true"
                onMouseOver={hoverProfileOpen()}
                color="inherit"
              >
                <img
                  src={Iconsimport["user.svg"]}
                  alt="user-icon"
                  width="20px"
                />
              </IconButton>
            </div>
          </Box>
        </Box>
      </Toolbar>
    </AppBar>
  );

  return (
    <div className={`${classes.grow} poco-community-header`}>
      {/* Heder app bar for desktop */}
      {rednderAppBar}
      {/* Header Menu Hover Section */}
      <HoverMenu anchor="top" hover={hoverMenu} close={hoverMenuClose}>
        {renderHoverMenuData()}
      </HoverMenu>
      {/* Header Profile Hover Section for desktop*/}
      <HoverMenu anchor="top" hover={profileHover} close={hoverProfileClose}>
        <UserProfile
          isProfileLoad={userProfileLoad}
          {...userProfile}
          {...topRankingUsers}
        />
      </HoverMenu>
      {/* mobile bottom app bar */}
      <MobileAppBar
        isProfileLoad={userProfileLoad}
        {...userProfile}
        {...topRankingUsers}
      />
      <HoverMenu anchor="top" hover={isSearchOpen}>
        <SearchBar close={handleSearchBarClose} />
      </HoverMenu>
    </div>
  );
}
