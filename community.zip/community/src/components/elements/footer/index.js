import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getFooterItems } from "../../../redux/actions/headerFooterAction";
import { Box, Typography, Grid } from "@material-ui/core";
import { Link } from "react-router-dom";
import logo from "../../../static/images/logo.png";
import './index.scss'

function Footer() {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getFooterItems());
  }, [dispatch]);

  const { footerItems } = useSelector((state) => state.footerItems);

  const renderFooterItems = (
    <Box className="poco-community-footer" display={{ xs: 'none', sm: 'block', md: 'block' }}>
      <Box display="flex">
        <Box flexGrow={5}></Box>
        <Box flexGrow={1}>
          <img src={logo} alt="" />
        </Box>
      </Box>
      <Grid container>
        {footerItems &&
          footerItems.map((item) => (
            <Grid item md={4} key={item.id}>
              <Grid container>
                <Grid item md={4}></Grid>
                <Grid item md={4}>
                  <Typography variant="h6">{item.primaryHeading}</Typography>
                  {item.utilityLinks.map((utility) => (
                    <Typography variant="body1" key={utility.id}>
                      <Link to={utility.path}>{utility.secondaryHeading}</Link>
                    </Typography>
                  ))}
                </Grid>
              </Grid>
            </Grid>
          ))}
      </Grid>
    </Box>
  );
  return renderFooterItems;
}

export default Footer;
