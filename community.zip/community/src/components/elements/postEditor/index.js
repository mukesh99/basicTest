import React from "react";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import "./index.scss";

export function PostEditor(props) {
  const { postRef, content, contentUpdate } = props;

  const modules = {
    toolbar: [
      [{ header: [1, 2, true], Paragraph:[1,2] }],
      [{ list: "ordered" }, { list: "bullet" }],
      ["link", "image", "video"],
      ["bold", "italic", "underline", "strike"], // toggled buttons
      [{ header: [1, 2, 3, 4, 5, 6, false] }], // header dropdown
      // [{ 'color': [] }, { 'background': [] }],         // dropdown with defaults
      [{ font: [] }], // font family
      [{ align: [] }], // text align
      ["clean"],
    ],
  };

  const formats = [
    "header",
    "font",
    "size",
    "bold",
    "italic",
    "underline",
    "strike",
    "blockquote",
    "list",
    "bullet",
    "script",
    "align",
    "link",
    "image",
    "code-block",
    "formula",
    "video",
  ];

  return (
    <div className="post-editor">
      <ReactQuill
        theme="snow"
        ref={postRef}
        value={content}
        modules={modules}
        formats={formats}
        onChange={contentUpdate}
      />
    </div>
  );
}
