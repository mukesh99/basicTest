import React from "react";
import { Box, Button, Grid } from "@material-ui/core";
import { Link } from 'react-router-dom';
import "./index.scss";

export function AddPost(props) {
  return (
    <div className="add-post-section">
      <Grid container>
        <Grid item xs={12} sm={12} md={12}>
          <Box
            display="flex"
            p={4}
            bgcolor="text.primary"
            justifyContent="center"
            height={70}
            className="d-none-xs"
          >
            <Link to='/addpost'>
            <Button
              size="large"
              variant="contained"
              color="secondary"
              fullWidth
              disableRipple
              disableFocusRipple
            >
              <strong>Add Post</strong>
            </Button>
            </Link>
          </Box>
        </Grid>
        <Grid item xs={12} sm={12} md={12}>
          <Box
            display="flex"
            mt={3}
            mb={3}
            p={2}
            bgcolor="text.primary"
            justifyContent="center"
            height={70}
            className="d-none-xs"
          >
            <Button
              size="large"
              variant="text"
              color="default"
              fullWidth
              disableRipple
              disableFocusRipple
            >
              <strong>Calendar</strong>
            </Button>
            <Button
              size="large"
              variant="text"
              color="default"
              fullWidth
              disableRipple
              disableFocusRipple
            >
              <strong>Tasks</strong>
            </Button>
          </Box>
        </Grid>
      </Grid>
    </div>
  );
}
