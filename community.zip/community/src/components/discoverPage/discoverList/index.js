import React, { useRef, useEffect } from "react";
import { Grid, Typography, Box } from "@material-ui/core";
// Reusable elements
import { PocoCard } from "components/elements/cards";

export default function DiscoverList(props) {
  const { discover } = props;
  const scrollView = useRef("null");

  useEffect(() => {
    // get url product url id to scroll into a section
    let url = window.location.pathname;
    var productSeriesId = url.substring(url.lastIndexOf('/') + 1);
    const productScroll = document.getElementById(productSeriesId);
    if(productScroll){
      productScroll.scrollIntoView({
        top:200,
      behavior: "smooth",
      block: "start",
      inline: "start"
     });
    }
  });
  const renderProductSeriesPost = () => {
    return (
      <React.Fragment>
        {discover?.map((post) => (
          <React.Fragment key={post.id}>
            <Box width="100%" p={3} pb={2}>
              <Box mb={3}>
                <PocoCard Img={post.bannerImage} height={300}  srolltoview={scrollView}/>
              </Box>
              <Typography
                variant="h5"
                id={post.id}
                display="block"
              >
                <strong>{post.name}</strong>
              </Typography>
            </Box>
            {post.tagData?.map((element) => (
              <Grid item xs={12} sm={6} md={6} component="span" key={element.id}>
                <PocoCard
                  Img={element.postThumbnail}
                  Tittle={element.postTitle}
                  ProfilePic={element.postAvatar}
                  UserName={element.postUserName}
                  lastSeen={element.postUserLastSeen}
                  tag={element.tagName}
                  view={element.postViews}
                  like={element.postLikes}
                />
              </Grid>
            ))}
          </React.Fragment>
        ))}
      </React.Fragment>
    );
  };
  return renderProductSeriesPost();
}
