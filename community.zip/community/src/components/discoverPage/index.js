import React, { useEffect } from "react";
// Redux selector
import { useDispatch, useSelector } from "react-redux";
// Matrial element
import { Grid, Box } from "@material-ui/core";
// reusable elements
import { AddPost } from "components/elements/addPost";
// child component
import DiscovertList from "./discoverList";
// Redux action calls
import { getDiscover } from "redux/actions/discoverPageAction";

import "./index.scss";

export default function DiscoverPage() {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getDiscover());
  }, [dispatch]);

  // Get product object from redux state
  const { discoverItems } = useSelector((state) => state.discover);

  return (
    <div className="product-page">
      <Box mt={10} mb={2} p={3}>
        <Grid container component="span" spacing={5}>
          <Grid item xs={12} sm={12} md={8} component="span">
            <Grid container spacing={5} component="span">
              <DiscovertList {...discoverItems} />
            </Grid>
          </Grid>
          <Grid item xs={12} sm={12} md={4} component="span">
            <AddPost />
          </Grid>
        </Grid>
      </Box>
    </div>
  );
}
