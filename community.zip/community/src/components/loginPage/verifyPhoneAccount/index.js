import React from 'react';
import {Link} from 'react-router-dom'
import { Typography, Box, Button
,Divider,Container,Grid,TextField} from
'@material-ui/core';


// importing Global component
// import {SocialIcons} from '../../../components/SocialIcons/SocialIcons'

function AccountVerificationwithPhonenumber (props){

return(
<React.Fragment>
    <Container>
        <Grid container>
            <div className="verify-account-section mt-3">
                <Grid container justify="center">
                    <Grid item xs={11} sm={6} md={5}>
                        <Grid container>
                            <Grid item xs={12} sm={12} md={12} align="center">
                                <Typography variant="h4"><strong>Create Poco Account</strong></Typography>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8}>
                                <Typography variant="subtitle1" color="inherit" className="mt-2" >A verification code has been sent to your device <strong class="text-primary">{"+91 9876543210"}</strong></Typography>
                            </Grid>
                            <Grid container spacing={2} className="mt-1">
                                <Grid item xs={8} sm={8} md={8} >
                                    <TextField id="Entercode" label="Enter Code" variant="outlined" fullWidth />
                                </Grid>
                                <Grid item xs={4} sm={4} md={4} >
                                <Typography variant="subtitle1" color="primary">
                                    <Link to=""> <u>Resend code</u></Link>
                                </Typography>
                                </Grid>
                            </Grid>
                            <Grid item xs={12} sm={12} md={12} className="mt-2">
                                <Button variant="contained" color="primary" size="large"
                                    fullWidth>Next</Button>
                                </Grid>
                            <Grid item xs={12} sm={12} md={12}>
                                <Link to="/createaccount/phonenumber">
                                <Button variant="contained" color="default" size="large" className="mt-1"
                                    fullWidth>Back</Button>
                                    </Link>
                            </Grid>
                            <Grid item xs={12} sm={12} md={12} className="mt-1" align="left">
                                    <Typography variant="subtitle1" color="primary">
                                      <Link to="" ><u>Didn't receive a verification code?</u></Link>
                                    </Typography>
                            </Grid>
                            <Grid item xs={12} sm={12} md={12}  align="center">
                                <Box display="flex" justifyContent="center" mt={5} flexWrap="nowrap">
                                    <Grid container>
                                        <Grid item xs={5} sm={5} md={5}>
                                            <Divider />
                                        </Grid>
                                        <Grid item xs={2} sm={2} md={2}>
                                            or
                                        </Grid>
                                        <Grid item xs={5} sm={5} md={5}>
                                            <Divider />
                                        </Grid>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={12} className="mt-1" align="center">
                                <Typography variant="subtitle1" color="inherit">Sign up with</Typography>
                            </Grid>
                            {/* <SocialIcons /> */}
                        </Grid>
                    </Grid>
                </Grid>
            </div>
        </Grid>
    </Container>
</React.Fragment>
)

}

export default AccountVerificationwithPhonenumber;