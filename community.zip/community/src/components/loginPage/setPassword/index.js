import React from "react";
import {
  Typography,
  Box,
  Button,
  Divider,
  Grid,
  TextField,
} from "@material-ui/core";

import { formStyle } from "core/theme/makeStyle";

export default function SetAccountPassword(props) {
  const classes = formStyle();
  return (
    <React.Fragment>
      <div className="setpassword-account-section">
        <Grid container justify="center">
          <Grid item xs={11} sm={8} md={4}>
            <Box mt={15}>
            <Grid container>
              <Grid item xs={12} sm={12} md={12} align="center">
                <Typography variant="h4">
                  <strong>Create Poco Account</strong>
                </Typography>
              </Grid>
              <Grid item xs={12} sm={12} md={12} className="mt-2">
                <Typography variant="h6">
                  <strong>Set password</strong>
                </Typography>
              </Grid>
              <form autoComplete="off" className={classes.root} > 
              <Grid item xs={12} sm={12} md={12} className="mt-1">
                <TextField
                  id="email"
                  label="Enter email Id"
                  variant="outlined"
                  fullWidth
                />
              </Grid>
              <Grid item xs={12} sm={12} md={12} className="mt-1">
                <TextField
                  id="Password"
                  label="Re-Enter password"
                  variant="outlined"
                  fullWidth
                />
              </Grid>
              <Grid item xs={10} sm={7} md={7}>
                <Typography
                  variant="subtitle2"
                  className="mt-1"
                  color="inherit"
                ></Typography>
              </Grid>
              <Grid item xs={12} sm={12} md={12} className="mt-1">
                <Button
                  variant="contained"
                  color="primary"
                  size="large"
                  fullWidth
                >
                  Submit
                </Button>
              </Grid>
              </form>
              <Grid item xs={12} sm={12} md={12} align="center">
                <Box
                  display="flex"
                  justifyContent="center"
                  mt={5}
                  flexWrap="nowrap"
                >
                  <Grid container>
                    <Grid item xs={5} sm={5} md={5}>
                      <Divider />
                    </Grid>
                    <Grid item xs={2} sm={2} md={2}>
                      or
                    </Grid>
                    <Grid item xs={5} sm={5} md={5}>
                      <Divider />
                    </Grid>
                  </Grid>
                </Box>
              </Grid>
              <Grid
                item
                xs={12}
                sm={12}
                md={12}
                className="mt-1"
                align="center"
              >
                <Typography variant="subtitle2" color="inherit">
                  Sign up with
                </Typography>
              </Grid>
              {/* <SocialIcons /> */}
            </Grid>
              </Box>
          </Grid>
        </Grid>
      </div>
    </React.Fragment>
  );
}
