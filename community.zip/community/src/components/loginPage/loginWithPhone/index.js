import React,{useState} from 'react';
import {Link} from 'react-router-dom'
import { Typography, Box, Button ,Divider,Grid,TextField} from
'@material-ui/core';

import {formStyle} from 'core/theme/makeStyle'

// importing Global component
// import {SocialIcons} from '../../../components/SocialIcons/SocialIcons'

export default function LoginWithPhoneNumber (props){
    const classes = formStyle(); 
  const [phonenumberLogin,setnumberphoneLogin] = useState({
        phoneNumber: 0,
        verificationCode:0,
        isPhonenumberValid: false,
        isVerificationCodevalid: false,
        errorPhonehelpertext:"",
        errorVerificationhelpertex:""
  })
  console.log(phonenumberLogin.verificationCode,"verifcatio code")
 return(
<React.Fragment>
    <div className="phonenumber-login-section ">

                <Grid container justify="center" alignContent="center" >
                    <Grid md={4}>
                  <Box justifyContent="center" display="flex" mt={15}>

                        <Typography variant="h4"><strong>Log in to your Poco Account</strong></Typography>
                  </Box>
                    <form className={classes.root}>
                    <Grid container spacing={2}>
                    <Grid item xs={4} sm={3} md={3}>
                        <TextField id="CtrCode" type="number" label="Contry Code" value="+91" variant="outlined" fullWidth disabled />
                    </Grid>
                    <Grid item xs={8} sm={9} md={9}>
                        <TextField id="countrycode" label="Phone number" name="phoneNumber" variant="outlined"
                        onChange={(e)=>setnumberphoneLogin({...phonenumberLogin,[e.target.name]:e.target.value})}
                        error={phonenumberLogin.isPhonenumberValid}
                        helperText={phonenumberLogin.errorPhonehelpertext}
                        required 
                        fullWidth />
                    </Grid>
                    </Grid>
                    <Grid container spacing={2}>
                    <Grid item xs={7} sm={8} md={8} className="mt-1">
                        <TextField id="verificode" label="Verification code" variant="outlined"
                        name="verificationCode"
                        onChange={(e)=>setnumberphoneLogin({...phonenumberLogin,[e.target.name]:e.target.value})}
                        error={phonenumberLogin.errorVerificationhelpertex}
                        fullWidth />
                    </Grid>
                    <Grid item xs={5} sm={4} md={4}>
                        <Button variant="contained" color="primary" size="large" className="mt-1"
                            fullWidth 
                            disabled={phonenumberLogin.verificationCode.length === 0 }
                            onClick={()=>{}}
                            >Get Code</Button>
                    </Grid>
                    </Grid>
                    <Grid item xs={12} sm={12} md={12}>
                        <Button variant="contained" type="submit" color="primary" size="large" className="mt-2"
                            fullWidth>Log in</Button>
                    </Grid>
                    </form>
                    <Grid item xs={12} sm={12} md={12}  align="center">
                        <Typography variant="subtitle2" color="inherit" >
                                <Link to="/login">Log in with Email / Password</Link>
                        </Typography>
                    </Grid>
                    <Grid item xs={12} sm={12} md={12}  align="center">
                        <Typography variant="subtitle2" color="inherit" >
                            <Link to="/createaccount/phonenumber">Sign up with Mobile number</Link>
                        </Typography>
                    </Grid>
                        <Box display="flex" justifyContent="center" flexWrap="nowrap">
                            <Grid container>
                                <Grid item xs={5} sm={5} md={5}>
                                    <Divider />
                                </Grid>
                                <Grid item xs={2} sm={2} md={2}>
                                    or
                                </Grid>
                                <Grid item xs={5} sm={5} md={5}>
                                    <Divider />
                                </Grid>
                            </Grid>
                        </Box>
                    <Grid item xs={12} sm={12} md={12} className="mt-1" align="center">
                    <Typography variant="subtitle2" color="inherit" >Log in with</Typography>
                    </Grid>
                    {/* <SocialIcons /> */}
                </Grid>
                </Grid>
    </div>
</React.Fragment>
)

}

