import React from 'react';
import {Link} from 'react-router-dom'
import { Typography, Box, Button,Divider,Grid,TextField,FormControlLabel,
Checkbox} from '@material-ui/core';

import {formStyle} from 'core/theme/makeStyle'
// importing Global component
import SocialMedia from "../socialMedia";

function CreateAccountWithPhonenumber (props){
    const classes = formStyle(); 
return(
<React.Fragment>
    <div className="create-account-phone-section mt-3">
        <Grid container justify="center">
            <Grid item xs={11} sm={7} md={4}>
                <Box mt={15}>
                <Grid container>
                    <Grid item xs={12} sm={12} md={12} align="center">
                        <Typography variant="h4"><strong>Create Poco Account</strong></Typography>
                    </Grid>
                    <form className={classes.root}>
                    <Grid container spacing={2} className="mt-2">
                    <Grid item xs={4} sm={4} md={3} >
                        <TextField id="CtrCode" label="Contry Code" value="+91" variant="outlined" fullWidth disabled />
                    </Grid>
                    <Grid item xs={8} sm={8} md={9}>
                        <TextField id="PhoneNumber" label="Phone number" variant="outlined" fullWidth />
                    </Grid>
                    </Grid>
                    <Grid item xs={12} sm={10} md={9}>
                    <FormControlLabel className="mt-1" control={ <Checkbox 
                        name="checkedB" color="primary" />}
                    label="* I agree to User Agreement. Please see our Privacy Policy here"/>
                    </Grid>
                    <Grid item xs={12} sm={12} md={12}>
                        <Button variant="contained" color="primary" size="large" className="mt-1"
                            fullWidth>Create Account</Button>
                    </Grid>
                    </form>
                    <Grid item xs={12} sm={12} md={12} className="mt-1" align="center">
                        <Typography variant="subtitle2" color="primary">
                            <Link to="/createaccount">Sign up with Email</Link>
                        </Typography>
                    </Grid>
                    <Grid item xs={12} sm={12} md={12} className="mt-1" align="center">
                            <Typography variant="subtitle2" color="inherit">
                            <Link to="/login/phonenumber">Log in</Link>     
                        </Typography> 
                    </Grid>
                    <Grid item xs={12} sm={12} md={12} className="mt-1" align="center">
                        <Box display="flex" justifyContent="center" flexWrap="nowrap">
                            <Grid container>
                                <Grid item xs={5} sm={5} md={5}>
                                    <Divider />
                                </Grid>
                                <Grid item xs={2} sm={2} md={2}>
                                    or
                                </Grid>
                                <Grid item xs={5} sm={5} md={5}>
                                    <Divider />
                                </Grid>
                            </Grid>
                        </Box>
                    </Grid>
                    <Grid item xs={12} sm={12} md={12} className="mt-1" align="center">
                    <Typography variant="subtitle2" color="inherit">Sign up with</Typography>
                    </Grid>
                    <SocialMedia />
                </Grid>
                </Box>
            </Grid>
        </Grid>
    </div>
</React.Fragment>
)

}

export default CreateAccountWithPhonenumber;