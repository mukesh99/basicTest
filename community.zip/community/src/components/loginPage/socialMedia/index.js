import React from "react";
import { Box, IconButton } from "@material-ui/core";

import { Iconsimport } from "core/utils";

export default function SocialMedia() {
  return (
    <React.Fragment>
      <Box display="flex" justifyContent="center" width="100%" mt={2}>
        <IconButton>
          <img src={Iconsimport["facebook.svg"]} alt="facebook" />
        </IconButton>
        <IconButton>
          <img src={Iconsimport["google.svg"]} alt="google" />
        </IconButton>
      </Box>
    </React.Fragment>
  );
}
