import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  Typography,
  Box,
  Button,
  Divider,
  Grid,
  TextField,
} from "@material-ui/core";
// component style
import { formStyle } from "core/theme/makeStyle";

import SocialMedia from "./socialMedia";
// Util function to vlidate email and password
import { validateEmailPassword } from "core/utils";

import "./index.scss";

export default function LoginPage(props) {
  const classes = formStyle();

  const [formValue, setfromValue] = useState({
    email: "",
    password: "",
  });

  // state to handle validation error
  const [error, setError] = useState({
    isValidEmail: false,
    errorEmailhelpertext: "",
    isPasswordValid: false,
    errorPasswordhelpertext: "",
  });

  // Form submit methods
  const handleSubmit = (event) => {
    event.preventDefault();
    let validatedData = validateEmailPassword(error, formValue);
    if (validatedData) setError(validatedData);

    // Form submit data
    const submitData = {
      email: validatedData.email,
      password: validatedData.password,
    };
    console.log(JSON.stringify(submitData));
  };
  return (
    <React.Fragment>
      <div className="login-section mt-3">
        <Grid container justify="center">
          <Grid item xs={11} sm={8} md={4} alignItems="center">
            <Box mt={15}>
              <Grid container>
                <Grid item xs={12} sm={12} md={12} align="center">
                  <Typography variant="h4">
                    <strong>Log in to your Poco Account</strong>
                  </Typography>
                </Grid>
                <form
                  autoComplete="off"
                  className={classes.root}
                  onSubmit={handleSubmit}
                >
                  <Grid item xs={12} sm={12} md={12} className="mt-2">
                    <TextField
                      id="email"
                      label="Email"
                      variant="outlined"
                      name="email"
                      margin="10"
                      onChange={(e) => {
                        setfromValue({
                          ...formValue,
                          [e.target.name]: e.target.value,
                        });
                      }}
                      error={error.isValidEmail}
                      helperText={error.errorEmailhelpertext}
                      required
                      fullWidth
                    />
                  </Grid>
                  <Grid item xs={12} sm={12} md={12} className="mt-1">
                    <TextField
                      id="Password"
                      label="Password"
                      variant="outlined"
                      name="password"
                      type="password"
                      onChange={(e) => {
                        setfromValue({
                          ...formValue,
                          [e.target.name]: e.target.value,
                        });
                      }}
                      error={error.isPasswordValid}
                      helperText={error.errorPasswordhelpertext}
                      required
                      fullWidth
                    />
                  </Grid>
                  <Grid item xs={12} sm={12} md={12} className="mt-1">
                    <Button
                      type="submit"
                      variant="contained"
                      color="primary"
                      size="large"
                      className="mt-1"
                      fullWidth
                    >
                      Log in
                    </Button>
                  </Grid>
                </form>
                {/* <Grid
                  item
                  xs={12}
                  sm={12}
                  md={12}
                  className="mt-2"
                  align="center"
                >
                  <Typography variant="subtitle2" color="primary">
                    <Link to="/login/phonenumber" color="primary">
                      Log in with SMS
                    </Link>
                  </Typography>
                </Grid> */}
                <Grid
                  item
                  xs={12}
                  sm={12}
                  md={12}
                  className="mt-1"
                  align="center"
                >
                  <Typography variant="subtitle2" color="inherit">
                    <Link to="/createaccount">Create account</Link>&nbsp; |
                    &nbsp;
                    <Link to="/setpassword">Forgot password?</Link>
                  </Typography>
                </Grid>
                <Grid
                  item
                  xs={12}
                  sm={12}
                  md={12}
                  className="mt-1"
                  align="center"
                >
                  <Box display="flex" justifyContent="center" flexWrap="nowrap">
                    <Grid container>
                      <Grid item xs={5} sm={5} md={5}>
                        <Divider />
                      </Grid>
                      <Grid item xs={2} sm={2} md={2}>
                        or
                      </Grid>
                      <Grid item xs={5} sm={5} md={5}>
                        <Divider />
                      </Grid>
                    </Grid>
                  </Box>
                </Grid>
                <Grid
                  item
                  xs={12}
                  sm={12}
                  md={12}
                  className="mt-1"
                  align="center"
                >
                  <Typography color="inherit" variant="subtitle2">
                    Log in with
                  </Typography>
                </Grid>
              </Grid>
            </Box>
            <SocialMedia />
          </Grid>
        </Grid>
      </div>
    </React.Fragment>
  );
}
