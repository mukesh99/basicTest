import React from "react";
import { Provider } from "react-redux";
import Reuter from './router/Router'
import ThemeProvide from "./core/theme/palate";
import ToastAlert from "components/elements/toast";
// import Login from "components/loginPage";
// import Createaccount from "components/loginPage/createPocoAccount";
// import SetAccountPassword from "components/loginPage/setPassword";
// import LoginWithPhoneNumber from "components/loginPage/loginWithPhone"
// import CreatePhoneAccount from "components/loginPage/createPhoneAccount"
// import verifyPhoneAccount from "components/loginPage/verifyPhoneAccount"
// import HomePage from "components/homePage";
// import ProductPage from "components/productPage";
// import DiscoverPage from "components/discoverPage";
// import AddpostPage from "components/addpostPage";
// import FeedbackPage from "components/feedbackPage";
// 
// import { Layout } from "components/elements/layout";
// import TabPanel from "components/userpage/userTab";
import store from "./redux/store";
import "./styles/App.scss";

function App() {
  return (
    <Provider store={store}>
      {/* Global component for client side alerts */}
      <ToastAlert />
      
        <div className="App">
          <ThemeProvide>
          <Reuter></Reuter>
          </ThemeProvide>
        </div>
      
    </Provider>
  );
}

export default App;
