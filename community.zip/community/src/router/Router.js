import React from 'react';
import { BrowserRouter, Route, Switch, Redirect } from 'react-router-dom';
import { Layout } from "components/elements/layout";
import Login from "components/loginPage";
import Createaccount from "components/loginPage/createPocoAccount";
import SetAccountPassword from "components/loginPage/setPassword";
import HomePage from "components/homePage";
import ProductPage from "components/productPage";
import DiscoverPage from "components/discoverPage";
import AddpostPage from "components/addpostPage";
import FeedbackPage from "components/feedbackPage";
import TabPanel from "components/userpage/userTab";

const Router = () =>(
    <BrowserRouter>
        <Switch>
        <Layout>
        <Route exact path="/login" component={Login} />
              <Route exact path="/createaccount" component={Createaccount} />
              <Route exact path="/setpassword" component={SetAccountPassword} />
                <Route exact path="/home" component={HomePage} />
                <Route exact path="/product/:id" component={ProductPage} />
                <Route exact path="/discover/:id" component={DiscoverPage} />
                <Route exact path="/addpost" component={AddpostPage} />
                <Route exact path="/profile" component={TabPanel} />
                <Route exact path="/feedback" component={FeedbackPage} />
                <Redirect to="/home" />
            <Redirect to="/home" />
            </Layout>
          </Switch>
    </BrowserRouter>
)


export default Router